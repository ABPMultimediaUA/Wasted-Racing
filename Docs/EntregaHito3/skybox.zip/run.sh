export LD_LIBRARY_PATH=./bin/:lib/sfml:lib/assimp:lib/sdl && ./bin/skybox
