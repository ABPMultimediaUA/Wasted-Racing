#include "TResourceTexture.h"
#include <iostream>

TResourceTexture::~TResourceTexture()
{
    glDeleteTextures(1, &textureID);
}

bool TResourceTexture::loadResource()
{
    //Attempt to load the file
    if(texture.loadFromFile(name))
    {
        active=true;
        //Get his width and height
        sizeX = texture.getSize().x;
        sizeY = texture.getSize().y;

        //Generate a OpenGL texture for later
        glGenTextures(1, &textureID);

        return true;
    }
    return false;
}

void TResourceTexture::draw()
{
    if(active)
    {
        //Bind and enable the texture
        glBindTexture(GL_TEXTURE_2D, textureID);
        glEnable(GL_TEXTURE_2D);
        
        //Set all the parameters of the texture
        glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_REPEAT);
        glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_REPEAT);
        glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_LINEAR);
        glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR); 

        //Set the texture to be drawn
        glTexImage2D(GL_TEXTURE_2D, 0, GL_RGBA8, (GLsizei)sizeX, (GLsizei)sizeY, 0, GL_RGBA, GL_UNSIGNED_BYTE, texture.getPixelsPtr());
    }
    else
    {
        glDisable(GL_TEXTURE_2D);
    }
}

void TResourceTexture::endDraw()
{
    glDisable(GL_TEXTURE_2D);
}