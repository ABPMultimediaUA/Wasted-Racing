#include "AcceptEvent.h"

AcceptEvent::AcceptEvent(FMOD::Studio::EventInstance* newEvent) : ISoundEvent(newEvent)
{

}
