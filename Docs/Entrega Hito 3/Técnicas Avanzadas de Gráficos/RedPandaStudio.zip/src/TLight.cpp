#include "TLight.h"

void TLight::beginDraw()
{
    
}

void TLight::endDraw()
{
    
}