#include "CocodrileGoodENEvent.h"

CocodrileGoodENEvent::CocodrileGoodENEvent(FMOD::Studio::EventInstance* newEvent) : ISoundEvent(newEvent)
{

}
