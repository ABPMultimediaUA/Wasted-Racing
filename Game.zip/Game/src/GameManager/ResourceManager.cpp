#include "ResourceManager.h"

void ResourceManager::init() {

}

void ResourceManager::update() {

}

void ResourceManager::close() {

}