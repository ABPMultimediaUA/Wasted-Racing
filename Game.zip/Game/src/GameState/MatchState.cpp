#include "MatchState.h"

void MatchState::init() {

}

void MatchState::update() {

}

void MatchState::draw() {

}

void MatchState::close() {
    
}