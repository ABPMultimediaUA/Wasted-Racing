#include "NetworkManager.h"

void NetworkManager::init() {

}

void NetworkManager::update() {

}

void NetworkManager::close() {

}