#pragma once

#include "../GameObject/GameObject.h"
#include <map>
#include "PhysicsManager.h"
#include "RenderManager.h"
#include "ItemManager.h"
#include "WaypointManager.h"
#include "AIManager.h"
#include "SensorManager.h"
#include "ScoreManager.h"

class ObjectManager{

public: 

    enum PlayerType{
            
        punk            = 0,      
        witch           = 1,      
        cyborg          = 2,      
        crocodile       = 3
    
    };

    //Constructor
    ObjectManager() {
        gameRunning = true;
    }

    //Destructor
    ~ObjectManager() {}

    //Initialization
    void init();

    //Shutdown
    void close();

    //Create an object and fire creation event
    GameObject::Pointer createObject(uint16_t id, GameObject::TransformationData transform);

    //Add an object
    void addObject(GameObject::Pointer ptr);

    //Delete an object
    void deleteObject(uint16_t id);

    //Get an object
    GameObject::Pointer getObject(uint16_t id);

    //Show the ids of the current objects
    void showObjects();

    //Init all objects
    void initObjects();

    //Static class getter
    static ObjectManager& getInstance();

    //Create Player and IA
    void createPlayer(GameObject::TransformationData tansform, int type, int move, int id, LAPAL::plane3f terrain, IComponent::Pointer terrainComponent); //Read .cpp 

    GameObject::Pointer createPunk(GameObject::TransformationData tansform, int id, LAPAL::plane3f terrain, IComponent::Pointer terrainComponent);
    GameObject::Pointer createWitch(GameObject::TransformationData tansform, int id, LAPAL::plane3f terrain, IComponent::Pointer terrainComponent);
    GameObject::Pointer createCyborg(GameObject::TransformationData tansform, int id, LAPAL::plane3f terrain, IComponent::Pointer terrainComponent);
    GameObject::Pointer createCrocodile(GameObject::TransformationData tansform, int id, LAPAL::plane3f terrain, IComponent::Pointer terrainComponent);

    void createMove(GameObject::Pointer obj, int move);

    //Game running getter and setter
    void setGameRunning(bool s) {   gameRunning = s;    }
    bool getGameRunning()       {   return gameRunning; }

private:

    //Map of objects
    std::map<uint16_t, GameObject::Pointer> objectsMap;

    bool gameRunning;

};