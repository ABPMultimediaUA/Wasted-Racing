#include "NetworkRaknet.h"

void NetworkRaknet::openNetwork() {

}

void NetworkRaknet::updateNetwork() {

}

void NetworkRaknet::closeNetwork() {
    
}

void NetworkRaknet::updateObject(int id) {

}

void NetworkRaknet::updateObjects() {

}