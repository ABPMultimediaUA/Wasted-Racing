#include "ItemRedShellComponent.h"



ItemRedShellComponent::ItemRedShellComponent(GameObject& newGameObject) : IItemComponent(newGameObject)
{
    speed = 200.f;
}

ItemRedShellComponent::~ItemRedShellComponent()
{

}

void ItemRedShellComponent::init()
{
    
}

void ItemRedShellComponent::update(float dTime)
{
    
}

void ItemRedShellComponent::close()
{
    
} 
 
 
