#include "LevelManager.h"

void LevelManager::init() {

}

void LevelManager::update() {

}

void LevelManager::close() {

}