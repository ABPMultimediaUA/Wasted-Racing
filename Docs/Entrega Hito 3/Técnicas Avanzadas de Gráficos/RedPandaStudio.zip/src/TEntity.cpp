#include "TEntity.h"

GLuint TEntity::programID;
GLuint TEntity::modelID;
GLuint TEntity::viewID;
GLuint TEntity::projectionID;
