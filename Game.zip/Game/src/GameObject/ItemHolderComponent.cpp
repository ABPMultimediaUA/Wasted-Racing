#include "ItemHolderComponent.h"
#include "../GameManager/ItemManager.h"


ItemHolderComponent::ItemHolderComponent(GameObject& newGameObject) : IComponent(newGameObject)
{
    
}

void ItemHolderComponent::init()
{

} 

void ItemHolderComponent::update(float dTime)
{

}

void ItemHolderComponent::close()
{

}
