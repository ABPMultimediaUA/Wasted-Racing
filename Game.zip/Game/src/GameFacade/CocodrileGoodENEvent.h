#pragma once

#include "ISoundEvent.h"

class CocodrileGoodENEvent : public ISoundEvent{
    public:
        CocodrileGoodENEvent(FMOD::Studio::EventInstance* newEvent);

};