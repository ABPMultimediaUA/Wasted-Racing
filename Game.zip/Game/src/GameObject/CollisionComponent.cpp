#include "CollisionComponent.h"
#include "../GameManager/ObjectManager.h"

//Initilizer
void CollisionComponent::init() {

}

//Update
void CollisionComponent::update(float dTime) {

}

//Closer
void CollisionComponent::close() {

} 