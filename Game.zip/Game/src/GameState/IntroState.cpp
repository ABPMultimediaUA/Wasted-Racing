#include "IntroState.h"

void IntroState::init() {

}

void IntroState::update() {

}

void IntroState::draw() {

}

void IntroState::close() {
    
}