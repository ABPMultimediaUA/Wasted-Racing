#pragma once
#include "TEntity.h"

class TAnimation : public TEntity{

private:
    

public:

    TAnimation() {}
    ~TAnimation() {}

    //Draw Methods
    void beginDraw() {}
    void endDraw() {}

};