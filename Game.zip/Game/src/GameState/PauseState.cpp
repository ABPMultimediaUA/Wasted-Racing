#include "PauseState.h"

void PauseState::init() {

}

void PauseState::update() {

}

void PauseState::draw() {

}

void PauseState::close() {
    
}