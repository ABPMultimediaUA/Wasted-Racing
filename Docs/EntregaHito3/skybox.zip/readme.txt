	_______________________________________________________________________________
	|  _    _           _           _   _   _                _           _         |
	| | |  | |         | |         | | | | | |              | |         | |        |
	| | |  | | __ _ ___| |_ ___  __| | | |_| | ___  _ __ ___| |__   __ _| |_ __ _  |
	| | |/\| |/ _` / __| __/ _ \/ _` | |  _  |/ _ \| '__/ __| '_ \ / _` | __/ _` | |
	| \  /\  / (_| \__ \ ||  __/ (_| | | | | | (_) | | | (__| | | | (_| | || (_| | |
	|  \/  \/ \__,_|___/\__\___|\__,_| \_| |_/\___/|_|  \___|_| |_|\__,_|\__\__,_| |
	|______________________________________________________________________________|


    Skybox demo:
	
        In order to execute this demo, execute the "run.sh" bash file.
        
        During the demo, the skybox can be activated and deactivated pressing any key.
        
    We hope this demo is useful to understand the skybox implementation.
