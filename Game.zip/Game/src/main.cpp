#include "Game.h"

#include <iostream>

int main(){

	std::cout << "Starting game..." << std::endl;
	
	Game game;
	
	game.Run();
	
	std::cout << "Exiting game..." << std::endl;
	
	return 0;  

}