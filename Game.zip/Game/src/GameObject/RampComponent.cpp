#include "RampComponent.h"

//Initilizer
void RampComponent::init() {

}

//Update
void RampComponent::update(float dTime) {

}

//Closer
void RampComponent::close() {

}