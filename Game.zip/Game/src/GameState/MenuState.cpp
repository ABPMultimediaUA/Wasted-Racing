#include "MenuState.h"

void MenuState::init() {

}

void MenuState::update() {

}

void MenuState::draw() {

}

void MenuState::close() {
    
}